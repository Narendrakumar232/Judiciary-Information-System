/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author student
 */
public class adjour2 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("  </ul>\n" +
                   
                           "<!doctype html>\n" +
                   "<html lang=\"en\">\n" +
                           "\n" +
                           "<head>\n" +
                           "\n" +
                           "  <meta charset=\"utf-8\">\n" +
                           "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
                           "  <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css\"\n" +
                           "    crossorigin=\"anonymous\">\n" +
                           "  <!-- Bootstrap CSS -->\n" +
                           "\n" +
                           "  <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css\" rel=\"stylesheet\"\n" +
                           "    integrity=\"sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC\" crossorigin=\"anonymous\">\n" +
                           "  <link rel=\"stylesheet\" href=\"sidebar.css\">\n" +
                           "  <title>JIS</title>\n" +
                           "</head>\n" +
                           "\n" +
                           "<body>\n" +
                           "  <nav class=\"navbar navbar-light bg-navbar sticky-top \" style='margin-right:-120px'>\n" +
                           "    <div class=\"container-fluid\">\n" +
                           "\n" +
                           "      <a class=\"navbar-brand\" href=\"#\">\n" +
                           "\n" +
                           "        <img src=\"ico.png\" alt=\"\" width=\"50\" height=\"50\" class=\"d-inline-block align-text-right\">\n" +
                           "\n" +
                           "        &nbsp;&nbsp;&nbsp;&nbsp; Judicial Information System\n" +
                           "      </a>\n" +
                           "\n" +
                          
                           "\n" +
                           "    </div>\n" +
                           "\n" +
                           "  </nav>\n" +
                           "  <!-- The sidebar -->\n" +
                           "<div class=\"sidebar\">\n" +
                           "  <ul>\n" +
                           "    <li>\n" +
                           "      <a href=\"Dashboard\"> <i class=\"fa-solid fa-gauge fa-2x\"></i><br><span class=\"item\"> Dashboard</span></a>\n" +
                           "      <div class=\"dropdown\">\n" +
                           "        <!-- <a href=\"#\">Overview</a>\n" +
                           "        <a href=\"#\">Analytics</a>\n" +
                           "        <a href=\"#\">Reports</a> -->\n" +
                           "      </div>\n" +
                           "    </li>\n" +
                           "    <li>\n" +
                           "      <a href=\"adjour2\"><i class=\"fa-sharp fa-solid fa-layer-group fa-2x\"></i><br><span class=\"item\">Adjourned</span></a>\n" +
                           "      <div class=\"dropdown\">\n" +
                           "        <!-- <a href=\"#\">Cases Pending</a>\n" +
                           "        <a href=\"#\">Cases Resolved</a>\n" +
                           "        <a href=\"#\">Cases Reopened</a> -->\n" +
                           "      </div>\n" +
                           "    </li>\n" +
                           "    <li>\n" +
                           "      <a href=\"solvedcases\"><i class=\"fa-solid fa-money-bill fa-2x\"></i><br><span class=\"item\">Solved Cases</span></a>\n" +
                           "      <div class=\"dropdown\">\n" +
                           "        <!-- <a href=\"#\">Cases by Type</a>\n" +
                           "        <a href=\"#\">Cases by Date</a> -->\n" +
                           "     \n" +
                           "      </div>\n" +
                           "    </li>\n" +
                           "    <li>\n" +
                           "      <a href=\"card.html\"><i class=\"fa-solid fa-earth-americas fa-2x\"></i><br><span class=\"item\">Browse Cases</span></a>\n" +
                           "      <div class=\"dropdown\">\n" +
                           "        <!-- <a href=\"#\">Cases by Type</a>\n" +
                           "        <a href=\"#\">Cases by Date</a>\n" +
                           "        <a href=\"#\">Cases by Location</a> -->\n" +
                           "      </div>\n" +
                           "    </li>\n" +
                           "    <li>\n" +
                           "      <a href=\"http://localhost:8080/home/login.html\"><i class=\"fa-sharp fa-solid fa-power-off fa-2x\"></i><br><span class=\"item\">Logout</span></a>\n" +
                           "    </li>\n</ul></div>");
            
             Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/JIS","root","Naren@232");
      
           
                String query = "select * from adjournment";
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery(query);
                
                
                 out.println("<html><head> <style>\n" +
"        table{border-collapse:collapse; width:50%; margin-left:400px;}\n" +
"        th,td{\n" +
"            border: 2px solid brown;\n" +
"            padding:15px;\n" +
"            text-align:center;\n" +
"        }\n" +
"        td{\n" +
"            height: 30px;\n" +
"            vertical-align: super;\n" +
"        }\n" +
"        tr:nth-child(even){\n" +
"            background-color: #fff;\n" +
"        }\n" +
"        tr:nth-child(odd){\n" +
"            background-color: #eee;\n" +
"        }\n" +
"        th{\n" +
"            color: white;\n" +
"            background-color: gray;\n" +
"            height: 50px;\n" +
"            \n" +
"        }\n" +
"        th:hover{\n" +
"            height: 70px;\n" +
"            border-bottom: 2px solid black;\n" +
"            background-color: green;\n" +
"        }\n" +
"        tr:hover{\n" +
"            background-color: gray;\n" +
"        }</style></head><body><h1 align='center'>All Adjourned Cases</h1><table><tr>"
                        + "<th>CIN</th>"
                        + "<th>Hearing Date</th>"
                        + "<th>Judge Name</th>"
                        + "<th>Adjourned Summary</th>"
                        +"</tr>");
                 
                 while(rs.next())
                {
                    
                    out.println("<tr><td>"+rs.getString(1)+"</td><td>");
                    out.println(rs.getString(2)+"</td><td>");
                    out.println(rs.getString(3)+"</td><td>");
                    out.println(rs.getString(4)+"</td></tr>");
                }
                out.println("</table></body></html>");
                    
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(adjour2.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(adjour2.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(adjour2.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(adjour2.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
