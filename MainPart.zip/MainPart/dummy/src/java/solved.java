/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author student
 */
public class solved extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     * @throws java.lang.ClassNotFoundException
     * @throws java.sql.SQLException
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!Doctype html>\n" +
"<html lang=\"en\">\n" +
"  <head>\n" +
"    \n" +
"    <meta charset=\"utf-8\">\n" +
"    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
"    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css\" crossorigin=\"anonymous\">\n" +
"    <!-- Bootstrap CSS -->\n" +
"    \n" +
"    <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC\" crossorigin=\"anonymous\">\n" +
"    <link rel=\"stylesheet\" href=\"sidebar.css\">\n" +
"    <title>JIS</title>\n" +
"  </head>\n" +
"  <body>\n" +
"    <nav class=\"navbar navbar-light bg-navbar sticky-top\">\n" +
"        <div class=\"container-fluid\">\n" +
"            \n" +
"          <a class=\"navbar-brand\" href=\"#\">\n" +
"            \n" +
"            <img src=\"ico.png\" alt=\"\" width=\"50\" height=\"50\" class=\"d-inline-block align-text-right\">\n" +
"                   \n" +
"            &nbsp;&nbsp;&nbsp;&nbsp; Judicial Information System  \n" +
"        </a>\n" +
"\n" +
"        </div>\n" +
"      </nav>\n" +
"     \n" +
"      <!-- The sidebar -->\n" +
"<div class=\"sidebar\">\n" +
"  <div class=\"dashboard\">    \n" +
"    <a href=\"index.html\"> <i class=\"fa-solid fa-gauge fa-2x\"></i><span class=\"align1\">Case Details</span></a> \n" +
"  </div>\n" +
"\n" +
"    <a href=\"adjourned\"> <i class=\"fa-sharp fa-solid fa-layer-group fa-2x\"></i><span class=\"align1\">Adjourned</span></a>\n" +
"    <a href=\"#\"><i class=\"fa-solid fa-money-bill fa-2x\"></i><span class=\"align\">Solved Cases</span> </a>\n" +
"    <a href=\"browsecases\"><i class=\"fa-solid fa-earth-americas fa-2x\"></i> <span class=\"align\">Browse Cases</span></a>\n" +
"<a href=\"addlawyer\"><i class=\"fa-solid fa-user-plus fa-2x\"></i><span class=\"align\">Add Lawyer</span></a>\n" +
"    <a href=\"addjudge\"><i class=\"fa-solid fa-user-plus fa-2x\"></i> <span class=\"align\">Add judge</span></a>" +
"    <a href=\"http://localhost:8080/home/login.html\"> <i class=\"fa-sharp fa-solid fa-power-off fa-2x\"></i class=\"align\">Log out</a>\n" +
"       \n" +
"    </div>\n" +
"\n" +
"  \n" +
"\n" +
"  <!-- Page content -->\n" +
"\n" +
"  <section class=\"addCase\">\n" +
"  <div class=\"content\">\n" +
"    <h2>Solved Cases details</h2>\n" +
"    <hr>\n" +
"    <form>\n" +
"      <div class=\"row\">\n" +
"        <div class=\"form-group col-md-6\">\n" +
"          <label for=\"inputEmail4\">CIN<span>*</span></label>\n" +
"          <input type=\"text\" class=\"form-control\" id=\"inputEmail4\" name=\"cin\" placeholder=\"\" required=\"true\">\n" +
"        </div>\n" +
"\n" +
"        <div class=\"form-group col-md-6\" >\n" +
"          <label for=\"inputPassword4\">Final Judgement Date<span>*</span></label>\n" +
"          <input type=\"text\" class=\"form-control\" id=\"inputPassword4\" name=\"fianldate\" placeholder=\"YYYY-MM-DD\" required=\"true\">\n" +
"        </div>\n" 
                    + "<div class=\"form-group col-md-6\" >\n" +
"          <label for=\"inputPassword4\">judge<span>*</span></label>\n" +
"          <input type=\"text\" class=\"form-control\" id=\"inputPassword4\" name=\"judge\" required=\"true\">\n" +
"        </div>"+
            "<div class=\"form-group col-md-6\" >\n" +
"          <label for=\"inputPassword4\">Summary<span>*</span></label>\n" +
"          <input type=\"text\" class=\"form-control\" id=\"inputPassword4\" name=\"summary\" required=\"true\">\n" +
"        </div>"+
                              "<div class=\"form-group col-md-6\" >\n" +
"          <label for=\"inputPassword4\">Status<span>*</span></label>\n" +
"          <input type=\"text\" class=\"form-control\" id=\"inputPassword4\" name=\"status\" required=\"true\">\n" +
"        </div>"+" <center>\n" +
"                <input type=\"submit\" style=\"background-color: rgb(238, 30, 103)\" name=\"submit\">\n" +
"          </center></body></html>");
            
            
            String cin2 = request.getParameter("cin");
            String finaldate2 = request.getParameter("fianldate");
            String judge2 = request.getParameter("judge");
            String summary2 = request.getParameter("summary");
            String status2 = request.getParameter("status");
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/JIS","root","Naren@232");
            PreparedStatement ps = con.prepareStatement("insert into solvecases values(?,?,?,?,?)");
            
            ps.setString(1,cin2);
            ps.setString(2,finaldate2);
            ps.setString(3,judge2);
            ps.setString(4,summary2);
            ps.setString(5,status2);
            
            int v=ps.executeUpdate();
            if(v>0)
            {
                response.sendRedirect("sucess4.html");
                        }
           
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(solved.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(solved.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
