/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author student
 */
public class register extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     * @throws java.lang.ClassNotFoundException
     * @throws java.sql.SQLException
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            String Cin2 = request.getParameter("cin");
            String defendant2 = request.getParameter("defendant");
            String defendant_add2 = request.getParameter("defendant_add");
            String crimetype2 = request.getParameter("crimetype");
            String crime_date2 = request.getParameter("crime_date");
            String crime_location2= request.getParameter("crime_location");
            String officer_name2 = request.getParameter("officer_name");
            String arrest_date2 = request.getParameter("arrest_date");
            String judge2 = request.getParameter("judge");
            String laywer2 = request.getParameter("laywer");
            String Starting2 = request.getParameter("Starting");
            String judgement2 = request.getParameter("judgement");
            String remark2 = request.getParameter("remark");
            
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/JIS","root","Naren@232");
            
            PreparedStatement ps = con.prepareStatement("insert into register values(?,?,?,?,?,?,?,?,?,?,?,?,?)");
            ps.setString(1,Cin2);
            ps.setString(2,defendant2);
            ps.setString(3,defendant_add2);
            ps.setString(4,crimetype2);
            ps.setString(5,crime_date2);
            ps.setString(6,crime_location2);
            ps.setString(7,officer_name2);
            ps.setString(8,arrest_date2);
            ps.setString(9,judge2);
            ps.setString(10,laywer2 );
            ps.setString(11,Starting2);
            ps.setString(12,judgement2 );
            ps.setString(13,remark2 );
           
            
            int v=ps.executeUpdate();
            if(v>0)
            {
                response.sendRedirect("reg.html");
            }
           
            /*out.println(v);
            if(v>0)
            {
                String query = "select * from register";
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery(query);
                out.println("<html><head> <style>\n" +
"        table{border-collapse:collapse; width:100%;}\n" +
"        th,td{\n" +
"            border: 2px solid brown;\n" +
"            padding:15px;\n" +
"            text-align:center;\n" +
"        }\n" +
"        td{\n" +
"            height: 30px;\n" +
"            vertical-align: super;\n" +
"        }\n" +
"        tr:nth-child(even){\n" +
"            background-color: #fff;\n" +
"        }\n" +
"        tr:nth-child(odd){\n" +
"            background-color: #eee;\n" +
"        }\n" +
"        th{\n" +
"            color: white;\n" +
"            background-color: gray;\n" +
"            height: 50px;\n" +
"            \n" +
"        }\n" +
"        th:hover{\n" +
"            height: 70px;\n" +
"            border-bottom: 2px solid black;\n" +
"            background-color: green;\n" +
"        }\n" +
"        tr:hover{\n" +
"            background-color: gray;\n" +
"        }</style></head><body><table><tr>"
                        + "<th>CIN</th>"
                        + "<th>Defendent</th>"
                        + "<th>Defendent address</th>"
                        + "<th>Crime type</th>"
                        + "<th>Crime date</th>"
                        + "<th>Crime location</th>"
                        + "<th>officer</th>"
                        + "<th>arrest date</th>"
                        + "<th>judge</th>"
                        + "<th>lawyer</th>"
                        + "<th>starting date</th>"
                        +"<th>judgement date</th>"
                        +"<th>summary</th>"
                        +"</tr>");
                        
       
                while(rs.next())
                {
                    
                    out.println("<tr><td>"+rs.getString(1)+"</td><td>");
                    out.println(rs.getString(2)+"</td><td>");
                    out.println(rs.getString(3)+"</td><td>");
                    out.println(rs.getString(4)+"</td><td>");
                    out.println(rs.getString(5)+"</td><td>");
                    out.println(rs.getString(6)+"</td><td>");
                    out.println(rs.getString(7)+"</td><td>");
                    out.println(rs.getString(8)+"</td><td>");
                    out.println(rs.getString(9)+"</td><td>");
                    out.println(rs.getString(10)+"</td><td>");
                    out.println(rs.getString(11)+"</td><td>");
                    out.println(rs.getString(12)+"</td><td>");
                    out.println(rs.getString(13)+"</td></tr>");
                }
                out.println("</table></body></html>");
                
            
            }
            else
            {
                out.println("not");
            }*/
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(register.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(register.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
