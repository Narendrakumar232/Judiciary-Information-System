/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author student
 */
public class browsecases extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     * @throws java.sql.SQLException
     * @throws java.lang.ClassNotFoundException
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, ClassNotFoundException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
           
            
             Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/JIS","root","Naren@232");
      
           
                String query = "select * from register";
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery(query);
                out.println("<html><head> <style>\n" +
"        table{border-collapse:collapse; width:20%; margin-left:70px;}\n" +
"        th,td{\n" +
"            border: 2px solid brown;\n" +
"            padding:5px;\n" +
"            text-align:center;\n" +
"        }\n" +
"        td{\n" +
"            height: 30px;\n" +
"            vertical-align: super;\n" +
"        }\n" +
"        tr:nth-child(even){\n" +
"            background-color: #fff;\n" +
"        }\n" +
"        tr:nth-child(odd){\n" +
"            background-color: #eee;\n" +
"        }\n" +
"        th{\n" +
"            color: white;\n" +
"            background-color: gray;\n" +
"            height: 50px;\n" +
"            \n" +
"        }\n" +
"        th:hover{\n" +
"            height: 70px;\n" +
"            border-bottom: 2px solid black;\n" +
"            background-color: green;\n" +
"        }\n" +
"        tr:hover{\n" +
"            background-color: gray;\n" +
"        }</style></head><body><h1 align='center'><br>All Pending Cases<br><br></h1><table><tr>"
                        + "<th>CIN</th>"
                        + "<th>Defendent</th>"
                        + "<th>Defendent address</th>"
                        + "<th>Crime type</th>"
                        + "<th>Crime date</th>"
                        + "<th>Crime location</th>"
                        + "<th>officer</th>"
                        + "<th>arrest date</th>"
                        + "<th>judge</th>"
                        + "<th>lawyer</th>"
                        + "<th>starting date</th>"
                        +"<th>judgement date</th>"
                        +"<th>summary</th>"
                        +"</tr>");
                        
       
                while(rs.next())
                {
                    
                    out.println("<tr><td>"+rs.getString(1)+"</td><td>");
                    out.println(rs.getString(2)+"</td><td>");
                    out.println(rs.getString(3)+"</td><td>");
                    out.println(rs.getString(4)+"</td><td>");
                    out.println(rs.getString(5)+"</td><td>");
                    out.println(rs.getString(6)+"</td><td>");
                    out.println(rs.getString(7)+"</td><td>");
                    out.println(rs.getString(8)+"</td><td>");
                    out.println(rs.getString(9)+"</td><td>");
                    out.println(rs.getString(10)+"</td><td>");
                    out.println(rs.getString(11)+"</td><td>");
                    out.println(rs.getString(12)+"</td><td>");
                    out.println(rs.getString(13)+"</td></tr>");
                }
                out.println("</table></body></html>");
                
            
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(browsecases.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(browsecases.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(browsecases.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(browsecases.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
