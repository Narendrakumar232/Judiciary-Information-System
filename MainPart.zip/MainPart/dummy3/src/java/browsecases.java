/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author student
 */
public class browsecases extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     * @throws java.sql.SQLException
     * @throws java.lang.ClassNotFoundException
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, ClassNotFoundException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("  </ul>\n" +
                   
                           "<!doctype html>\n" +
                   "<html lang=\"en\">\n" +
                           "\n" +
                           "<head>\n" +
                           "\n" +
                           "  <meta charset=\"utf-8\">\n" +
                           "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
                           "  <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css\"\n" +
                           "    crossorigin=\"anonymous\">\n" +
                           "  <!-- Bootstrap CSS -->\n" +
                           "\n" +
                           "  <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css\" rel=\"stylesheet\"\n" +
                           "    integrity=\"sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC\" crossorigin=\"anonymous\">\n" +
                           "  <link rel=\"stylesheet\" href=\"sidebar.css\">\n" +
                           "  <title>JIS</title>\n" +
                           "</head>\n" +
                           "\n" +
                           "<body>\n" +
                           "  <nav class=\"navbar navbar-light bg-navbar sticky-top \" style='margin-right:-120px'>\n" +
                           "    <div class=\"container-fluid\">\n" +
                           "\n" +
                           "      <a class=\"navbar-brand\" href=\"#\">\n" +
                           "\n" +
                           "        <img src=\"images/ico.png\" alt=\"\" width=\"50\" height=\"50\" class=\"d-inline-block align-text-right\">\n" +
                           "\n" +
                           "        &nbsp;&nbsp;&nbsp;&nbsp; Judicial Information System\n" +
                           "      </a>\n" +
                           "\n" +
                           "      <span class=\"lname\"> lawyer Name <i class=\"fa-solid fa-user fa-2x\"></i></span>\n" +
                           "\n" +
                           "    </div>\n" +
                           "\n" +
                           "  </nav>\n" +
                           "  <!-- The sidebar -->\n" +
                           "<div class=\"sidebar\">\n" +
                           "  <ul>\n" +
                           "    <li>\n" +
                           "      <a href=\"Dashboard\"> <i class=\"fa-solid fa-gauge fa-2x\"></i><br><span class=\"item\"> Dashboard</span></a>\n" +
                           "      <div class=\"dropdown\">\n" +
                           "        <!-- <a href=\"#\">Overview</a>\n" +
                           "        <a href=\"#\">Analytics</a>\n" +
                           "        <a href=\"#\">Reports</a> -->\n" +
                           "      </div>\n" +
                           "    </li>\n" +
                           "    <li>\n" +
                           "      <a href=\"adjour2\"><i class=\"fa-sharp fa-solid fa-layer-group fa-2x\"></i><br><span class=\"item\">Adjourned</span></a>\n" +
                           "      <div class=\"dropdown\">\n" +
                           "        <!-- <a href=\"#\">Cases Pending</a>\n" +
                           "        <a href=\"#\">Cases Resolved</a>\n" +
                           "        <a href=\"#\">Cases Reopened</a> -->\n" +
                           "      </div>\n" +
                           "    </li>\n" +
                           "    <li>\n" +
                           "      <a href=\"solvedcases\"><i class=\"fa-solid fa-money-bill fa-2x\"></i><br><span class=\"item\">Solved Cases</span></a>\n" +
                           "      <div class=\"dropdown\">\n" +
                           "        <!-- <a href=\"#\">Cases by Type</a>\n" +
                           "        <a href=\"#\">Cases by Date</a> -->\n" +
                           "     \n" +
                           "      </div>\n" +
                           "    </li>\n" +
                           "    <li>\n" +
                           "      <a href=\"browsecases\"><i class=\"fa-solid fa-earth-americas fa-2x\"></i><br><span class=\"item\">Browse Cases</span></a>\n" +
                           "      <div class=\"dropdown\">\n" +
                           "        <!-- <a href=\"#\">Cases by Type</a>\n" +
                           "        <a href=\"#\">Cases by Date</a>\n" +
                           "        <a href=\"#\">Cases by Location</a> -->\n" +
                           "      </div>\n" +
                           "    </li>\n" +
                           "    <li>\n" +
                           "      <a href=\"#\"><i class=\"fa-sharp fa-solid fa-power-off fa-2x\"></i><br><span class=\"item\">Logout</span></a>\n" +
                           "    </li>\n</ul></div>");
            
             Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/JIS","root","Naren@232");
      
           
                String query = "select * from register";
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery(query);
                out.println("<html><head> <style>\n" +
"        table{border-collapse:collapse; width:20%; margin-left:70px;}\n" +
"        th,td{\n" +
"            border: 2px solid brown;\n" +
"            padding:5px;\n" +
"            text-align:center;\n" +
"        }\n" +
"        td{\n" +
"            height: 30px;\n" +
"            vertical-align: super;\n" +
"        }\n" +
"        tr:nth-child(even){\n" +
"            background-color: #fff;\n" +
"        }\n" +
"        tr:nth-child(odd){\n" +
"            background-color: #eee;\n" +
"        }\n" +
"        th{\n" +
"            color: white;\n" +
"            background-color: gray;\n" +
"            height: 50px;\n" +
"            \n" +
"        }\n" +
"        th:hover{\n" +
"            height: 70px;\n" +
"            border-bottom: 2px solid black;\n" +
"            background-color: green;\n" +
"        }\n" +
"        tr:hover{\n" +
"            background-color: gray;\n" +
"        }</style></head><body><h1 align='center'>All Pending Cases</h1><table><tr>"
                        + "<th>CIN</th>"
                        + "<th>Defendent</th>"
                        + "<th>Defendent address</th>"
                        + "<th>Crime type</th>"
                        + "<th>Crime date</th>"
                        + "<th>Crime location</th>"
                        + "<th>officer</th>"
                        + "<th>arrest date</th>"
                        + "<th>judge</th>"
                        + "<th>lawyer</th>"
                        + "<th>starting date</th>"
                        +"<th>judgement date</th>"
                        +"<th>summary</th>"
                        +"</tr>");
                        
       
                while(rs.next())
                {
                    
                    out.println("<tr><td>"+rs.getString(1)+"</td><td>");
                    out.println(rs.getString(2)+"</td><td>");
                    out.println(rs.getString(3)+"</td><td>");
                    out.println(rs.getString(4)+"</td><td>");
                    out.println(rs.getString(5)+"</td><td>");
                    out.println(rs.getString(6)+"</td><td>");
                    out.println(rs.getString(7)+"</td><td>");
                    out.println(rs.getString(8)+"</td><td>");
                    out.println(rs.getString(9)+"</td><td>");
                    out.println(rs.getString(10)+"</td><td>");
                    out.println(rs.getString(11)+"</td><td>");
                    out.println(rs.getString(12)+"</td><td>");
                    out.println(rs.getString(13)+"</td></tr>");
                }
                out.println("</table></body></html>");
                
            
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(browsecases.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(browsecases.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(browsecases.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(browsecases.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
