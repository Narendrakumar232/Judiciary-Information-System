/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author student
 */
public class Dashboard extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     * @throws java.lang.ClassNotFoundException
     * @throws java.sql.SQLException
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/JIS","root","Naren@232");
            PreparedStatement ps = con.prepareStatement("select count(*) from register");
            ResultSet rs;
            rs = ps.executeQuery();
            rs.next();
            int count = rs.getInt(1);
            PreparedStatement ps2 = con.prepareStatement("select count(CIN) from adjournment");
            ResultSet rs2;
            rs2 = ps2.executeQuery();
            rs2.next();
            int count2 = rs2.getInt(1);
            PreparedStatement ps3 = con.prepareStatement("select count(*) from solvecases");
            ResultSet rs3;
            rs3 = ps3.executeQuery();
            rs3.next();
            int count3 = rs3.getInt(1);
            int pending = count-count3;
            
            
            
            
            
            
            
            
           out.println("  </ul>\n" +
                   
                           "<!doctype html>\n" +
                   "<html lang=\"en\">\n" +
                           "\n" +
                           "<head>\n" +
                           "\n" +
                           "  <meta charset=\"utf-8\">\n" +
                           "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
                           "  <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css\"\n" +
                           "    crossorigin=\"anonymous\">\n" +
                           "  <!-- Bootstrap CSS -->\n" +
                           "\n" +
                           "  <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css\" rel=\"stylesheet\"\n" +
                           "    integrity=\"sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC\" crossorigin=\"anonymous\">\n" +
                           "  <link rel=\"stylesheet\" href=\"sidebar.css\">\n" +
                           "  <title>JIS</title>\n" +
                           "</head>\n" +
                           "\n" +
                           "<body>\n" +
                           "  <nav class=\"navbar navbar-light bg-navbar sticky-top\">\n" +
                           "    <div class=\"container-fluid\">\n" +
                           "\n" +
                           "      <a class=\"navbar-brand\" href=\"#\">\n" +
                           "\n" +
                           "        <img src=\"images/ico.png\" alt=\"\" width=\"50\" height=\"50\" class=\"d-inline-block align-text-right\">\n" +
                           "\n" +
                           "        &nbsp;&nbsp;&nbsp;&nbsp; Judicial Information System\n" +
                           "      </a>\n" +
                           "\n" +
                           "      <span class=\"lname\"> lawyer Name <i class=\"fa-solid fa-user fa-2x\"></i></span>\n" +
                           "\n" +
                           "    </div>\n" +
                           "\n" +
                           "  </nav>\n" +
                           "  <!-- The sidebar -->\n" +
                           "<div class=\"sidebar\">\n" +
                           "  <ul>\n" +
                           "    <li>\n" +
                           "      <a href=\"Dashboard\"> <i class=\"fa-solid fa-gauge fa-2x\"></i><br><span class=\"item\"> Dashboard</span></a>\n" +
                           "      <div class=\"dropdown\">\n" +
                           "        <!-- <a href=\"#\">Overview</a>\n" +
                           "        <a href=\"#\">Analytics</a>\n" +
                           "        <a href=\"#\">Reports</a> -->\n" +
                           "      </div>\n" +
                           "    </li>\n" +
                           "    <li>\n" +
                           "      <a href=\"adjour2\"><i class=\"fa-sharp fa-solid fa-layer-group fa-2x\"></i><br><span class=\"item\">Adjourned</span></a>\n" +
                           "      <div class=\"dropdown\">\n" +
                           "        <!-- <a href=\"#\">Cases Pending</a>\n" +
                           "        <a href=\"#\">Cases Resolved</a>\n" +
                           "        <a href=\"#\">Cases Reopened</a> -->\n" +
                           "      </div>\n" +
                           "    </li>\n" +
                           "    <li>\n" +
                           "      <a href=\"solvedcases\"><i class=\"fa-solid fa-money-bill fa-2x\"></i><br><span class=\"item\">Solved Cases</span></a>\n" +
                           "      <div class=\"dropdown\">\n" +
                           "        <!-- <a href=\"#\">Cases by Type</a>\n" +
                           "        <a href=\"#\">Cases by Date</a> -->\n" +
                           "     \n" +
                           "      </div>\n" +
                           "    </li>\n" +
                           "    <li>\n" +
                           "      <a href=\"browsecases\"><i class=\"fa-solid fa-earth-americas fa-2x\"></i><br><span class=\"item\">Browse Cases</span></a>\n" +
                           "      <div class=\"dropdown\">\n" +
                           "        <!-- <a href=\"#\">Cases by Type</a>\n" +
                           "        <a href=\"#\">Cases by Date</a>\n" +
                           "        <a href=\"#\">Cases by Location</a> -->\n" +
                           "      </div>\n" +
                           "    </li>\n" +
                           "    <li>\n" +
                           "      <a href=\"#\"><i class=\"fa-sharp fa-solid fa-power-off fa-2x\"></i><br><span class=\"item\">Logout</span></a>\n" +
                           "    </li>\n</ul></div>"
                   
                   + "<section id=\"Dashboard\" style=\"margin-left:'120px'\">\n" +
"  <br><br><br>\n" +
"  <div class=\"ld\">\n" +
"    <h3 class=\"center\">\n" +
"    New Cases </h3>\n" +
"    <span class=\"dnumfont\">0"+count+"</span>\n" +
"  </div>\n" +
"  <div class=\"ld\">\n" +
"    <h3>\n" +
"    pending cases</h3>\n" +
"    <span class=\"dnumfont\">0"+pending+"</span>\n" +
"  </div>\n" +
"  <div class=\"ld\">\n" +
"  <h3>\n" +
"    adjourned cases\n" +
"  </h3>\n" +
"  <span class=\"dnumfont\"> 0"+count2+"</span>\n" +
"  </div>\n" +
"  <div class=\"ld\">\n" +
"    <h3>\n" +
"    solved cases\n" +
"  </h3>\n" +
"  <span class=\"dnumfont\"> 0"+count3+"</span>\n" +
"  </div>\n" +
"\n" +
"\n" +
"</section></body></html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Dashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Dashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
